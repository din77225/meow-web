# Dot hop

Best for: A short one or two word title that lands above your head in the first seconds of a Reel, or a long-form intro beat. Orientation: vertical (9:16), works at 16:9 too.

## Look
- One or two short words (the preview says "dot hop.") in a heavy rounded sans, about 170 px on a 1080x1920 frame.
- Yellow #F4D00A with a soft dark shadow, in the empty space above your head.
- Optional small white line above it (for example "add this").

## Motion
A dot hops from letter to letter, each landing pops that letter up, and it ends as the full stop. It lands within the first 2 seconds, then holds. A short pop or whoosh as the word lands.

## Specs
Preview is 540x960 (9:16), 30 fps, real speed (its first 0.2 s shows a leftover word from a previous take, ignore it). Sizes at 1080x1920.
- Canvas: 1080x1920 base. 1080x1350: same sizes if there is room above the head, otherwise 140 px. 1920x1080: about 130 px, centred above the head or in the third beside it.
- Palette: word and dot #F4D00A. Small line #FFFFFF. Shadow rgba(0,0,0,0.35), 0 4px 16px (soft, no hard edge).
- Fonts: default Nunito Black (900) from Google Fonts, or Gilroy ExtraBold if you own it. Fallback: "Nunito", "Arial Rounded MT Bold", system-ui, sans-serif. Small line in Nunito ExtraBold (800).
- Sizes at 1080 wide: word 170 px (ascender height about 118 px), letter-spacing 0. Small line 72 px (ascender height about 54 px). Gap from the small line's baseline to the top of the word about 44 px. Hopping dot 20 px across; it ends at the size and position of the font's own full stop (about 32 px).
- Layout: centred. Word baseline at about y 474 (25% down), small line baseline at about y 312. Leave at least 60 px between the word's lowest point and the top of the hair. Keep 60 px side margins.
- Letter positions: measure each letter with measureText from @remotion/layout-utils (same font, size and weight as the render, after the font has loaded). Never use fixed widths. The dot's landing x for each letter is that measured letter's centre. The space between words is measured too, and the final landing x is the full stop's measured centre.
- Timing (30 fps): small line fades in on frames 9 to 12. Dot appears at frame 18 just left of the first letter. It hops about every 5 frames (3 to 6), with a longer hop of about 9 frames across the space between words. Hop arc peaks about 90 px above the baseline (ease up with Easing.out(Easing.quad), down with Easing.in(Easing.quad)). On each landing that letter springs up from 40 px below and 50% scale to its place, spring {damping: 9, stiffness: 180, mass: 0.6}. The last landing (about frame 60, 2.0 s) becomes the full stop. Hold to the end.

## Known pitfalls
- Leave clear space above the head. If the shot is framed tight, the word lands on the hair: reframe wider, or move the word lower and smaller.
- Keep it short: up to about 9 characters in total at this size (two short words are fine). Fit the headline with fitText/measureText from @remotion/layout-utils so it never overflows the frame; shrink the size rather than run past the 60 px margins.
- In a React style object, `font:` must come before `lineHeight`, or the shorthand resets it and the word jumps up the frame.
