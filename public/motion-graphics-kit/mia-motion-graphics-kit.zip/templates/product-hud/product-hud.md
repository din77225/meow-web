# Product HUD

This is an effect recipe used by the main skill, not another skill to install.

## Look
A soft, premium heads-up display over the supplied product image or video: dark mauve translucent label panels with a pink accent bar, readable feature labels, thin white leader lines ending in small crosshair targets, plus-sign registration marks and faint thin arcs around the product, and a light condensed title. It is HUD interface styling in the product's own colours, not a neon gaming look and not gameplay footage.

## Specs
Preview is 1280x720 (16:9), 24 fps, real speed. Sizes below are at 1080 px wide; multiply by 1.78 for 1920x1080. Timings are in frames at 30 fps.
- Canvas: 16:9 base. 1080x1920 and 1080x1350: same px sizes, title at the top, labels stacked above and below the product with longer leader lines, nothing in the bottom 20% of 9:16.
- Palette:
  - Panels #5D5257 at about 90% opacity, 3 px left accent bar #FC9DB4 on feature panels
  - Panel text #F7EEEF, panel caption #FC9DB4 (pink, letter-spaced)
  - Title: first word #FBF3EE, second word #A7747A
  - Subtitle #655757, its flanking rules 1 px #655757
  - Leader lines, targets, plus marks and arcs #FFFFFF at 70 to 90% opacity
- Fonts (free on Google Fonts): title and close-up headlines in a condensed sans. Default Oswald (title Light 300, headlines SemiBold 600). Labels and captions in Montserrat SemiBold (600), uppercase, letter-spacing 0.15 to 0.3em. Fallback: "Arial Narrow", Arial, sans-serif.
- Sizes at 1080 wide: title cap height about 68 px (font about 95 px), letter-spacing 0.15em. Subtitle 14 px, letter-spacing 0.4em, with 80 px rules either side. End-card label panels about 215x32 px with 12 px text. Close-up feature panel about 548x84 px, headline 36 px, caption 12 px. Leader lines 1 px. Targets 18 px circles with a centre dot and a crosshair. Plus marks 22 px. Arcs 1 px. No corner radius on panels.
- Layout: title centred at the top, about 30 px from the edge. Plus marks near the four corners, inset about 7%. Two big faint arcs hug the left and right of the product. Panels sit in negative space at the frame sides (inside a 1.5% edge margin), each with an elbow leader line to a target on the named feature. Close-ups: one panel, bottom right, leader to the feature.
- Timing: graphics start about 9 frames after each cut. Title fades in over 6 frames, subtitle and rules about 8 frames later, arcs and plus marks fade in over about 15 frames. Panels slide 16 px in from the outer edge and fade over 6 frames, about 10 frames apart; each leader line draws over 8 frames after its panel, then the target pops (4 frames). Close-up panel: headline first, caption 6 frames later. Everything cuts with the shot.

## Build
Inspect every shot, create new time-stamped anchors for this footage and align callouts to visible features. Use a tracked plane only when perspective supports it. Hide graphics when their target is occluded. Build new anchor positions for each new input; never reuse coordinates from a different clip. Reveal panels progressively and make one main callout readable at a time. Fit the title and panel text with fitText/measureText from @remotion/layout-utils so nothing overflows its panel or the frame. Keep the product unobstructed. For still images use fixed anchors; for video reset tracking at cuts. Do not invent technical measurements or game statistics.

## Check
Use real shot boundaries and a fresh tracking map. Preserve the approved base footage. Put copy, font, colour, timings and anchors in config. Check intermediate frames and the exported audio. The example design does not provide universal tracking coordinates.

## Copy prompt
See prompt.txt in this folder. Replace bracketed fields with your inputs; use NONE where an optional item does not apply.
