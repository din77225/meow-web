# Talking head captions

Style ID: th-captions
Best for: YouTube talking heads, explainers and ad reads, with captions that land on the right words

## Look
Short caption groups sit in the empty wall space beside the speaker and appear word by word, right as each word is said. Plain mixed-case text does most of the work. Once or twice per passage a big word lands in a heavy rounded face, tucked a little behind the speaker's hair, so it feels part of the room. Light text on darker wall, dark text on a bright wall or door.

## Motion
Each word rises a few pixels and fades in as it's spoken, never before. A big word lands with one firm, soft settle. A sentence stays in one zone and reads top to bottom; the next sentence can jump to the other side. A group fades out quickly when the next one starts on the same side.

## Specs
Preview is 1920x1080, 30 fps, from a 1280x720 talking head scaled up 1.5x.
- Canvas: 1920x1080 base. 1080x1920: same rules, groups sit above the head or in the lower third (keep clear of the platform's buttons), big word tucked behind the top of the head. 1080x1350: like 9:16 with less room, so use fewer words per group.
- Palette (swap for your brand):
  - Light text #FFF4E8 (cream) with a soft shadow 0 2px 14px rgba(20,6,30,.45)
  - Dark text #2A1233 (plum) with a soft light glow 0 1px 10px rgba(255,255,255,.55)
  - Accent #FF3D8B (pink) for anchors and one big word
  - No boxes or panels behind captions
- Fonts (free, from Google Fonts or @fontsource): support Inter 500, anchor Inter 800, big word Nunito 900. Fallback: Arial, sans-serif. Load them from public/fonts before measuring anything.
- Sizes at 1920 wide: support 58 to 64 px, anchor 92 to 112 px, big word 250 to 270 px. Line height 1.04, big word 0.9. Gap between cues in a group about 18% of the previous cue's size.
- Layout: measure the speaker first (the matte's left and right edge at the rows where text goes). Groups start about 40 px outside those edges: left zone x 90 to about 610, right zone x 1140 to about 1840. Keep text at least 40 px from the face and mouth, and above raised hands. A big word overlaps the hair by about 15% of its width, on its outer letter, never on the face.
- Layer order: the frame, the big words, the speaker cut-out (the same frame masked by its matte), then all other captions on top.
- Timing: each word lands 2 frames before it's spoken. Support and anchor words fade and rise 16 px over 6 frames, Easing.out(Easing.cubic). Big words: spring {damping: 13, stiffness: 170, mass: 0.9}, rising 40 px and settling from 1.06 to 1.0. A group fades out over 0.2 s, 0.05 s before the next group on that side starts. Hold a big word at least 0.8 s.

## Build recipe
1. Eyes and ears: pull frames to notes/frames/<clip>/, transcribe with word timestamps, fix names Whisper mishears.
2. Matte: on a Mac run scripts/person_matte.swift on the frames. Check it over a flat colour (both shoulders, hands). No matte? Keep every word beside the speaker.
3. Write caption-plan.json like caption-plan.example.json: one entry per cue with group, role (support, anchor, hero), text, x, y, size, colour, alignment and the word times; a score and a one-line reason for each hero.
4. Build with TalkingHeadCaptions.tsx: it draws the frame as images (frames/0001.jpg...) so the cut-out never drifts, stacks each group in one zone, and reveals every word on its time.
5. Show three stills (a support group, a big word, the densest moment) before the full render.

## Known pitfalls
- Plan x positions from the matte, not by eye. The speaker moves; measure the edge across the frames each big word is on.
- Fixed y for every cue makes wrapped lines overlap. Stack cues in a group instead.
- Too much of a big word behind the hair hides the letter that makes it readable. Keep it to about 15%.
- White text on a white door disappears. Pick light or dark text per zone.
- Google Fonts can time out in a render. Ship the font files in public/fonts.
- Two sentences on screen at once is fine only when they sit on opposite sides and the first is just finishing.
