// Talking head captions: designed captions on a talking-head clip, with big words tucked behind the speaker.
// Layers, bottom to top: the frame, the big words, the speaker cut out with their matte, the small captions.
// Inputs in public/: frames/0001.jpg... (the clip as frames), mattes/0001.png... (white = person, same names),
// take.wav (the voice), caption-plan.json (every cue with its word times), fonts/.
// The cut-out is the same frame masked by its matte, so it can never drift out of sync with the video.
import React from 'react';
import {AbsoluteFill, Audio, Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig, Easing} from 'remotion';
import plan from '../public/caption-plan.json';

type Word = {w: string; t: number};
type Cue = {id: string; group: string; start: number; end: number; text: string; role: 'support' | 'anchor' | 'hero';
  x: number; y: number; size: number; color: string; align: 'left' | 'right'; words: Word[]};

const FONT_CSS = `
@font-face{font-family:'Inter';font-weight:500;src:url(${staticFile('fonts/inter-latin-500-normal.woff2')}) format('woff2')}
@font-face{font-family:'Inter';font-weight:800;src:url(${staticFile('fonts/inter-latin-800-normal.woff2')}) format('woff2')}
@font-face{font-family:'Nunito';font-weight:900;src:url(${staticFile('fonts/nunito-latin-900-normal.woff2')}) format('woff2')}`;

const pad = (n: number) => String(n).padStart(4, '0');
const FRAMES = 422; // number of frame files in public/frames (change for your clip)

// One group = one sentence: its cues stack top to bottom in one zone, at the first cue's x and y.
// Both layers lay out the whole group, and hide the cues that belong to the other layer, so they line up exactly.
const Group: React.FC<{cues: Cue[]; layer: 'behind' | 'front'}> = ({cues, layer}) => {
  const f = useCurrentFrame(); const {fps} = useVideoConfig();
  const t = f / fps, c0 = cues[0];
  const out = interpolate(t, [c0.end - 0.2, c0.end], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  if (t < c0.start - 0.1 || out <= 0) return null;
  return <div style={{position: 'absolute', top: c0.y, ...(c0.align === 'left' ? {left: c0.x} : {right: 1920 - c0.x}),
    width: (c0 as any).w ?? 560, display: 'flex', flexDirection: 'column', alignItems: c0.align === 'left' ? 'flex-start' : 'flex-end', opacity: out}}>
    {cues.map((c, k) => {
      const hero = c.role === 'hero', anchor = c.role === 'anchor';
      const mine = (layer === 'behind') === hero;
      const light = c.color.toUpperCase() !== '#2A1233';
      const shadow = hero ? 'none' : light ? '0 2px 14px rgba(20,6,30,.45)' : '0 1px 10px rgba(255,255,255,.55)';
      return <div key={c.id} style={{position: 'relative', left: (c as any).dx ?? 0, visibility: mine ? 'visible' : 'hidden', marginTop: k === 0 ? 0 : Math.round(cues[k - 1].size * 0.18),
        fontFamily: hero ? 'Nunito' : 'Inter', fontWeight: hero ? 900 : anchor ? 800 : 500, fontSize: c.size, lineHeight: hero ? 0.9 : 1.04,
        letterSpacing: hero ? '-0.02em' : anchor ? '-0.015em' : '0', color: c.color, textShadow: shadow, textAlign: c.align, whiteSpace: hero ? 'nowrap' : 'normal'}}>
        {c.words.map((w, i) => {
          const lf = f - Math.round(w.t * fps) + 2; // land 2 frames before the word
          if (lf < 0) return <span key={i} style={{opacity: 0}}>{w.w}{i < c.words.length - 1 ? ' ' : ''}</span>;
          const s = hero ? spring({frame: lf, fps, config: {damping: 13, stiffness: 170, mass: 0.9}}) : interpolate(lf, [0, 6], [0, 1], {extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)});
          const y = hero ? interpolate(s, [0, 1], [40, 0]) : interpolate(s, [0, 1], [16, 0]);
          const sc = hero ? interpolate(s, [0, 1], [1.06, 1]) : 1;
          return <span key={i} style={{display: 'inline-block', opacity: Math.min(1, s * 1.4), transform: `translateY(${y}px) scale(${sc})`, transformOrigin: 'bottom'}}>{w.w}{i < c.words.length - 1 ? '\u00a0' : ''}</span>;
        })}</div>;
    })}
  </div>;
};

export const TalkingHeadCaptions: React.FC = () => {
  const f = useCurrentFrame();
  const n = pad(Math.min(f + 1, FRAMES));
  const cues = (plan as any).cues as Cue[];
  const groups = Object.values(cues.reduce((g: Record<string, Cue[]>, c) => ((g[c.group] ||= []).push(c), g), {}));
  const frame = staticFile(`frames/${n}.jpg`), matte = staticFile(`mattes/${n}.png`);
  return <AbsoluteFill style={{background: '#000'}}>
    <style>{FONT_CSS}</style>
    <Img src={frame} style={{position: 'absolute', inset: 0, width: '100%', height: '100%'}} />
    {groups.map((g) => <Group key={'b' + g[0].group} cues={g} layer="behind" />)}
    <Img src={frame} style={{position: 'absolute', inset: 0, width: '100%', height: '100%',
      WebkitMaskImage: `url(${matte})`, maskImage: `url(${matte})`, WebkitMaskSize: '100% 100%', maskSize: '100% 100%', maskMode: 'luminance'} as any} />
    {groups.map((g) => <Group key={'f' + g[0].group} cues={g} layer="front" />)}
    <Audio src={staticFile('take.wav')} />
  </AbsoluteFill>;
};
