# Product doodle

This is an effect recipe used by the main skill, not another skill to install.

## Look
Rough charcoal brush lettering for the product name and tagline, feature notes in white handwriting on torn charcoal tape labels, thin white hand-drawn arrows, rose underline strokes and small rose stars that guide attention to the product. Everything boils slightly like hand animation.

## Specs
Preview is 1280x720 (16:9), 24 fps, real speed. Sizes below are at 1080 px wide; multiply by 1.78 for 1920x1080. Timings are in frames at 30 fps.
- Canvas: 16:9 base. 1080x1920 and 1080x1350: keep the same px sizes, title across the top in two lines if needed, labels stacked left and right of the product, nothing in the bottom 20% of 9:16 (platform UI).
- Palette:
  - Brush lettering and label tape #302B2A
  - Label text and arrows #FCF8F5
  - Rose underlines and stars #C77986
  - No background changes, the doodles sit on the footage
- Fonts (all free on Google Fonts): title and signature in a rough brush marker, default Permanent Marker, fallback "Rock Salt", cursive. Label text in a casual handwriting, default Kalam Bold (700), fallback "Caveat Brush", cursive. Lowercase small words like "on" drop to about 40% size.
- Sizes at 1080 wide: title cap height about 100 px (font about 130 px). Signature ("CLOUD FLOW" style, bottom right) 32 px. Labels about 195x60 px rough rectangles with ragged edges, slightly rotated (-3 to +3 degrees), text 27 px. Arrows 2.5 px stroke with a small open arrowhead. Rose underlines 4 px, a little tapered. Stars about 34 px, 2 px rose outline.
- Layout: title top centre about 40 px from the top, signature bottom right inside a 5% margin. Labels in the empty space at the left and right of the product, with the arrow tip ending just short of the named feature. Keep the product itself clear.
- Timing: graphics start about 9 frames after each cut. Title fades in word by word, 3 frames apart, each a 4 frame fade (about 14 frames for the whole title). Underline draws 6 frames, starting about 12 frames after the title. Arrows draw on over 12 to 15 frames. Labels pop in over 5 frames (scale 0.8 to 1, spring {damping: 12, stiffness: 160, mass: 0.7}), their arrow starts 6 frames later. Stars pop in last. Boil: change the seeded wobble every 4 frames (about 8 per second). Everything cuts away with the shot.

## Build
Use the supplied image or clip. Match a supplied reference or propose a hand-drawn design in code first. Build editable handwriting-style text, SVG arrows and stars. Fit the title with fitText/measureText from @remotion/layout-utils so it never overflows the frame. Use seeded stepped line variations, about eight per second as a starting point, for a doodle-boil feel. Anchor decorations to visible features, keep the main subject unobstructed and reset at cuts in video; use fixed anchors for a still image.

## Check
Use real shot boundaries and a fresh tracking map. Preserve the approved base footage. Put copy, font, colour, timings and anchors in config. Check intermediate frames and the exported audio. The example design does not provide universal tracking coordinates.

## Copy prompt
See prompt.txt in this folder. Replace bracketed fields with your inputs; use NONE where an optional item does not apply.
