# Product editorial

This is an effect recipe used by the main skill, not another skill to install.

## Look
Oversized fashion-editorial typography, a refined serif headline paired with small sans-serif details, restrained leader lines and generous negative space. Where a valid subject mask exists, place the large headline behind the product. Use a clear feature headline for each relevant beat. A small italic serif tagline in capitals sits bottom right and thin white flowing lines sweep behind the product.

## Specs
Preview is 1280x720 (16:9), 24 fps, real speed. Sizes below are at 1080 px wide; multiply by 1.78 for 1920x1080. Timings are in frames at 30 fps.
- Canvas: 16:9 base. 1080x1920: masthead stacked on two lines at the top (fit to the width), product in the middle, labels above and below it. 1080x1350: masthead one line, fit to the width, labels at the sides.
- Palette:
  - Masthead #9A6A68 (dusty rose, with a fine grain texture at low opacity)
  - Italic tagline and label titles #956E6E
  - Feature headline #5A4243
  - Small captions #8B7573
  - Flowing lines #FFFFFF at 60 to 80% opacity
  - Leader lines #5A4243 at 1 px, with a 6 px dot at the feature end
- Fonts (free on Google Fonts): masthead and tagline in a condensed high-contrast serif, default Instrument Serif (tagline in Instrument Serif Italic), fallback "Bodoni Moda", Didot, Georgia, serif. Feature headlines and labels in Montserrat Bold (700), uppercase. Captions in Montserrat Medium (500), uppercase, letter-spacing 0.3em.
- Sizes at 1080 wide: masthead cap height about 210 px (font about 300 px), fit to 84% of the width. Tagline about 60 px, with a 1 px rule about 150 px long on its left. Close-up feature headline 34 px on two lines, caption 12 px. End-card label titles 20 px, letter-spacing 0.2em, with 15 px captions under them.
- Layout: masthead centred at the top (about 35 px from the top edge) and behind the product through a subject mask. Tagline bottom right inside a 4% margin. Close-up headlines top left in a 5% margin, leader line from under the caption to the feature. End card: one label block left, one right, in negative space beside the product. Two bundles of 6 to 8 thin flowing lines sweep in from the left and right edges behind the product.
- Timing: masthead fades in over 9 frames starting about 9 frames after the cut. Flowing lines draw in over about 24 frames. Tagline wipes on left to right over about 18 frames, word by word. Close-up headlines: each line fades and rises 10 px over 6 frames, 4 frames apart, caption after, then the leader line draws over 10 frames. End card labels follow the same pattern about 0.3 s apart. An optional soft light glint with a few sparkles sweeps across the named feature in close-ups. Everything cuts with the shot.

## Build
Use the supplied product image or clip. If a style reference is provided, match it; otherwise propose a static editorial design in code first. Rebuild the type in code. Fit the masthead with fitText/measureText from @remotion/layout-utils so it never overflows the frame. Use a subject mask only where text goes behind the product. Keep labels in negative space, and reset anchors at cuts. Label the actual features the user names, only when visible. Do not assume the product is footwear. Match the approved font and colour treatment.

## Check
Use real shot boundaries and a fresh tracking map. Preserve the approved base footage. Put copy, font, colour, timings and anchors in config. Check intermediate frames and the exported audio. The example design does not provide universal tracking coordinates.

## Copy prompt
See prompt.txt in this folder. Replace bracketed fields with your inputs; use NONE where an optional item does not apply.
