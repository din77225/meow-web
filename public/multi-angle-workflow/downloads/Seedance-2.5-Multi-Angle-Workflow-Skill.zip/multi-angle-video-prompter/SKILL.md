---
name: multi-angle-video-prompter
description: Plan new camera coverage for an existing video, write source-led multi-angle prompts for Seedance 2.5 only, and revise prompts after comparing generated results. Use when the user wants the same event from different camera positions, rather than a new story or a generic text-to-video scene.
---

# Seedance 2.5 Multi-Angle Workflow Skill

Turn a source clip and the user's creative notes into a compact camera plan. Preserve the observed event; change the viewpoint and only the other elements the user requests. This is a planning and checking aid, not a guarantee of identity, timing, geometry or audio fidelity.

## Model scope

This skill prepares prompts for Seedance 2.5 only, using the reference-video workflow demonstrated in OpenArt. It runs in a chat assistant; Seedance receives the resulting prompt and uploaded references, not the skill itself. Compatibility with Seedance 2.0 or other video models is not established. If another model is selected, flag it as outside this skill’s scope instead of presenting the prompt as validated for that model. Even within Seedance 2.5, results require human review.

## Default input: human notes

The user can watch the source and provide confirmed event notes and camera preferences. Uploading the source video to the chat assistant is optional, not a prerequisite. The source is still supplied to Seedance 2.5 in OpenArt. If no inspectable video is supplied to the assistant, work from the notes, state that they have not been independently verified, and ask only for consequential missing information. This skill replaces the standalone helper; do not require both.

## 1. Establish the evidence

Use the supplied video, available screenshots and user notes. Never claim to have watched or heard material you cannot inspect. State that limitation and draft only from confirmed notes; ask for missing evidence when it changes the plan.

Identify the selected clip's duration, aspect ratio, source-video label, actual uploaded references, desired look, camera preferences and audio intention. Reuse supplied answers. Ask one short grouped question only for consequential gaps. Require a location guide and character references for this workflow, plus prop references when relevant. If the location guide is missing, ask for its label; do not offer to write the prompt without one.

Before writing, make a short event summary in the correct order. Track who interacts with whom, object ownership, movement toward physical landmarks, and any repeated speech. Distinguish visible facts from interpretation. Do not infer a character's identity, emotion, language or exact words from a blurry frame or audience comments. Flag uncertain details outside the generation prompt for human review.

List the actual input bindings. A character sheet controls appearance; the source controls actions and spatial relationships. Include the required location guide in the input mapping and final prompt, plus relevant prop references. If an input is missing, request it rather than inventing an upload label. Do not recommend an unused sheet as though it produced an example result. Reference labels must match the selected platform's interface.

## 2. Plan coverage, not replacement choreography

Use time windows for camera changes across the selected clip. State the time origin if this is an excerpt. Let the source determine the pace within each window. Add only enough event context to identify the intended moment; avoid guessed subsecond action schedules.

Each shot needs a clear subject, shot size, physical camera position and, if moving, its direction. Anchor geometry to people and landmarks rather than ambiguous screen-left/screen-right. Separate camera motion from subject motion: a frontal tracking shot can have the camera move backward while the subject continues along the original path. Do not make the subject turn or reverse to satisfy the framing.

Keep actor names consistent and unambiguous. Specify counts when verified and useful. Avoid assuming every character remains visible from a new viewpoint. Preserve source order, relative positions, hand/object relationships and movement paths as instructions, without implying the model can enforce them perfectly.

Prefer an achievable number of shots for the event. A wider or longer shot can make a busy interaction easier to judge, but is not a proven fix. Use shot-size contrast where it helps. Retaining the original angle is allowed if it serves the user's plan.

## 3. Choose the audio mode

- **Source-led:** ask the model to use the reference voices, language, delivery, repetitions and timing as its guide, with matching lip sync. Do not write an approximate transcript that could replace the original. If the user highlights dialogue, quote only verified words and all required repetitions, subordinate to source timing rather than rigid speech timestamps.
- **Scripted replacement:** use the user's approved words, speaker and repetitions. Make clear that this changes the source audio. Do not silently choose this mode.
- **Silent or new sound:** follow the requested sound design.

Music, narration and offscreen voices are separate choices, not universal bans. If the user wants no music, say so once. If removing bystanders, distinguish them from an offscreen main character. Generated audio is not guaranteed to preserve the original recording; exact audio preservation may require using the licensed original soundtrack in editing. Do not upload audio to another service or spend credits merely because you are preparing a prompt.

## 4. Write and check

Use the required four-part output contract in references/prompt-template.md: preservation paragraph; complete reference mapping including location; timed camera coverage with confirmed event context; separate Style: and Audio: paragraphs. Return a finished prompt, not a plan for writing one. Missing required reference bindings or camera-window boundaries, overlaps, and unresolved contradictions require one short grouped clarification before final output. Never silently change cut times. Unknown spoken words do not block source-led audio. Do not attach a verified quote to a shot unless that association is known. Keep useful detail, remove repetition and speculative corrections. Prefer positive descriptions; use a short exclusion only when necessary to express the user's request. Do not impose an arbitrary word count, film-stock recipe or duration offset. Keep Style: to the requested look, lighting and colour; do not add an unrequested mood, emotion or colour grade.

Check the draft against the evidence:
- Are event order, identity labels, object transfers and travel direction consistent?
- Do camera instructions accidentally demand different actions or impossible visibility?
- Do windows cover the requested segment without gaps or overlaps? Are they camera windows rather than invented action deadlines?
- Are every upload label and dialogue quotation real and verified?
- Does the audio instruction contradict the source-led goal or the user's sound choices?

If evidence conflicts with a user note, flag it and resolve the conflict rather than silently changing the story. Unknowns belong outside the model-ready block.

Return the complete prompt in one code block. Outside it, add at most two short lines: genuine open questions or camera choices the user should check. Do not list the checks you ran or repeat caveats from earlier replies. Give settings only when requested. Read current model options from the interface when available; otherwise mark settings unverified. Do not invent prices or promise that preparing a prompt authorizes generation.

## 5. Revise from results

Compare source and result at matching events as well as matching timestamps. Check identity, contact/hand use, direction, event order, timing, camera and audio separately. Say what is observed versus a hypothesis about why it failed.

First remove a demonstrable prompt/source contradiction. If there is none, report the remaining failure as unresolved model behavior, not automatically user error. One good segment or one failed run cannot prove a wording rule or model superiority.

For a diagnostic retry, propose one changed variable: clearer camera position, fewer cuts, a shorter segment, or a verified appearance reference. Preserve successful instructions and return the whole revised prompt plus a short change note. Present these as tests, not fixes guaranteed to work. Respect the user's generation budget and approval scope.

For an edit, keep usable sections and assemble them. Explain honestly that this workflow creates candidate coverage requiring human selection; it does not reconstruct an exact 3D scene or deliver a reliable one-click remake.
