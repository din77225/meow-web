# Required output contract

Return one complete generation prompt in a single code block. Four parts in order; no numbered headings inside the block. The last part contains separate Style: and Audio: paragraphs. Expand the user's rough draft; do not merely repeat a checklist or return a camera plan.

```text
Keep the same subjects, positions, movement paths, event order and timing in [video label]. Change the camera coverage [and requested style]. [Brief confirmed story clarification, if useful.]

References: [each actual image label and subject, including the required location guide]. Character/prop sheets guide appearance. The location guide supplies layout and landmarks; the source video guides action and movement.

[start–end]s: [shot size/type, angle, physical camera position and camera movement]. [Confirmed event context].
[start–end]s: ...

Style: [requested look, lighting and colour only; no unrequested mood, emotion or grade].

Audio: [chosen audio policy; verified lines and repetitions if supplied; source-led delivery/timing and lip sync when requested; only requested exclusions].
```

Use all actual input labels. Cover the full selected clip with the user's camera windows. Missing required reference bindings, missing window boundaries, overlaps or contradictions require one short grouped clarification before final output. Never silently repair cut times or invent an upload. The location guide is required; if it is missing, ask for its label and do not offer a version without it. Do not demand a transcript for source-led sound when the user does not know the words. Include verified lines at the related shot only when that association is known; otherwise retain them in Audio without assigning invented timings.

Camera motion and subject motion are separate: a camera facing a moving person may track backward while that person continues forward along the source path. Do not invent gestures, physical contact or emotions to fill out a shot. If only overall event order is supplied, retain that order without inventing exact event timestamps.

Keep validation commentary out of the finished prompt. Name the spoken language only when the user stated it. Outside the block, keep to at most two short lines of genuine questions or choices to check. Do not copy rules about missing evidence or invented details into camera lines. One overall source-timing instruction and concise positive event context are enough; avoid repeating cautions on every shot.
